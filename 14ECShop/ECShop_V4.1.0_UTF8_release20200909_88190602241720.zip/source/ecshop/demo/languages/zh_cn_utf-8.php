<?php

/**
 * ECSHOP 鍗囩骇绋嬪簭璇?█鏂囦欢
 * ============================================================================
 * * 鐗堟潈鎵€鏈 2005-2018 涓婃捣鍟嗘淳缃戠粶绉戞妧鏈夐檺鍏?徃锛屽苟淇濈暀鎵€鏈夋潈鍒┿€
 * 缃戠珯鍦板潃: http://www.ecshop.com
 * ----------------------------------------------------------------------------
 * 杩欎笉鏄?竴涓?嚜鐢辫蒋浠讹紒鎮ㄥ彧鑳藉湪涓嶇敤浜庡晢涓氱洰鐨勭殑鍓嶆彁涓嬪?绋嬪簭浠ｇ爜杩涜?淇?敼鍜
 * 浣跨敤锛涗笉鍏佽?瀵圭▼搴忎唬鐮佷互浠讳綍褰㈠紡浠讳綍鐩?殑鐨勫啀鍙戝竷銆
 * ============================================================================
 * $Author: liubo $
 * $Date: 2009-12-14 17:22:19 +0800 (涓€, 2009-12-14) $
 * $Id: zh_cn_utf-8.php 16882 2009-12-14 09:22:19Z liubo $
*/

$_LANG['prev_step']         = '涓婁竴姝ワ細';
$_LANG['next_step']         = '涓嬩竴姝ワ細';
$_LANG['select_language_title']       =  'ECSHOP鍗囩骇绋嬪簭 绗?姝?鍏?姝 閫夋嫨璇?█缂栫爜';
$_LANG['readme_title']                =  'ECSHOP鍗囩骇绋嬪簭 绗?姝?鍏?姝 璇存槑椤?;
$_LANG['checking_title']                =  'ECShop鍗囩骇绋嬪簭 绗?姝?鍏?姝 鐜??妫€娴?;
$_LANG['check_system_environment']          = '妫€娴嬬郴缁熺幆澧?;

$_LANG['copyright']                     = '&copy; 2005-2018 <a href="http://www.ecshop.com" target="_blank">涓婃捣鍟嗘淳缃戠粶绉戞妧鏈夐檺鍏?徃</a>銆備繚鐣欐墍鏈夋潈鍒┿€?;
$_LANG['is_last_version']             = '鎮ㄧ殑ECSHOP宸叉槸鏈€鏂扮増鏈?紝鏃犻渶鍗囩骇銆?;

$_LANG['readme_page']                =  '璇存槑椤?;
$_LANG['notice'] = '鏈?▼搴忕敤浜庡皢 ECSHOP 鍗囩骇鍒 <strong>%s</strong>銆傝?鍕垮繀鎸夌収浠ヤ笅鐨勫崌绾ф柟娉曡繘琛屽崌绾э紝鍚﹀垯鍙?兘浜х敓鏃犳硶鎭㈠?鐨勫悗鏋溿€傚?鏋滀綘宸茬粡鏁村悎浜嗚?鍧涜蒋浠讹紝鏈??鍗囩骇灏嗗彇娑堟暣鍚堬紝浠ュ悗浼氬憳鏁村悎璇峰埌ucenrer涓?繘琛屾暣鍚堛€?;
$_LANG['usage1'] = '璇风‘璁ゅ凡缁忓畨瑁呬簡 UCenter锛屽惁鍒欙紝璇峰埌 <a href="http://www.discuz.com" target="_blank">Comsenz 浜у搧涓?績</a> 涓嬭浇骞朵笖瀹夎?锛岀劧鍚庡啀缁х画銆侟br />';
$_LANG['usage2']  = '<a href="../admin">鐧诲綍鍚庡彴</a>锛孅span style="color:red;font-weight:bold;font-size:18px;">澶囦唤</span>鏁版嵁搴撹祫鏂欙紱';
$_LANG['usage3']  = '鍏抽棴鐜版湁鐨 ECSHOP %s 绯荤粺锛?;
$_LANG['usage4']  = '瑕嗙洊鎬т笂浼 ECSHOP %s 鐨勫叏閮ㄦ枃浠跺埌鏈嶅姟鍣?紱';
$_LANG['usage5']  = '涓婁紶鏈?▼搴忓埌 ECSHOP 鎵€鍦ㄧ殑鐩?綍涓?紱';
$_LANG['usage6']  = '杩愯?鏈?▼搴忥紝鐩村埌鍑虹幇鍗囩骇瀹屾垚鐨勬彁绀恒€?;
$_LANG['method']  = '鍗囩骇鏂规硶';
$_LANG['charset']  = '缂栫爜纭??';

$_LANG['faq']  = '甯歌?闂??';

$_LANG['basic_config']                           = '鍩烘湰閰嶇疆淇℃伅';
$_LANG['config_path']                           = '閰嶇疆鏂囦欢璺?緞';
$_LANG['db_host']                           = '鏁版嵁搴撲富鏈?;
$_LANG['db_name']                           = '鏁版嵁搴撳悕';
$_LANG['db_user']                           = '鐢ㄦ埛鍚?;
$_LANG['db_pass']                           = '瀵嗙爜';
$_LANG['db_prefix']                         = '琛ㄥ墠缂€';
$_LANG['timezone']                         = '鏃跺尯璁剧疆';
$_LANG['cookie_path']                      = 'COOKIE璺?緞';
$_LANG['admin_dir']                        = '绠＄悊涓?績鏍硅矾寰?;

$_LANG['dir_priv_checking']                 = '鐩?綍鏉冮檺妫€娴?;
$_LANG['template_writable_checking']        = '妯℃澘鍙?啓鎬ф?鏌?;
$_LANG['rename_priv_checking']              = '鐗瑰畾鐩?綍淇?敼鏉冮檺妫€鏌?;
$_LANG['cannt_write']                     =  '涓嶅彲鍐?;
$_LANG['can_write']                       = '鍙?啓';
$_LANG['cannt_modify']                    = '涓嶅彲淇?敼';
$_LANG['not_exists']                      = '涓嶅瓨鍦?;
$_LANG['recheck']                         = '閲嶆柊妫€鏌?;
$_LANG['all_are_writable']                = '鎵€鏈夋ā鏉匡紝鍏ㄩ儴鍙?啓';

$_LANG['update_now']                    = '绔嬪嵆鍗囩骇';
$_LANG['done'] = '鎭?枩锛屾偍宸茬粡鎴愬姛鍗囩骇鍒癊CSHOP <strong>%s</strong>';
$_LANG['upgrade_error_title']                    = 'ECShop鍗囩骇绋嬪簭 鍗囩骇澶辫触';
$_LANG['upgrade_done_title'] = 'ECShop鍗囩骇绋嬪簭 鍗囩骇鎴愬姛';
$_LANG['go_to_view_my_ecshop'] = '鍓嶅線 ECSHOP 棣栭〉';
$_LANG['go_to_view_control_panel'] = '鍓嶅線 ECSHOP 鍚庡彴绠＄悊涓?績 ';
$_LANG['dir_readonly']          = '%s 鏂囦欢涓嶅彲鍐欙紝璇锋?鏌ユ偍鐨勬湇鍔″櫒璁剧疆銆?;
$_LANG['monitor_title']          = '鍗囩骇绋嬪簭鐩戣?鍣?;
$_LANG['wait_please']          = '姝ｅ湪鍗囩骇涓?紝璇风◢鍊欌€︹€︹€︹€?;
$_LANG['js_error']          = '瀹㈡埛绔疛avaScript鑴氭湰鍙戠敓閿欒?銆?;
$_LANG['create_ver_failed']          = '鍒涘缓鐗堟湰瀵硅薄澶辫触';
$_LANG['goto_charset_convert']  = '杞?悜锛氭暟鎹?簱缂栫爜杞?崲';
$_LANG['goto_members_import']  = '杞?悜锛氫粠UCenter瀵煎叆浼氬憳鏁版嵁';

/* 瀹㈡埛绔疛S璇?█椤 */
$_LANG['js_languages']['display_detail']                   = '鏄剧ず缁嗚妭';
$_LANG['js_languages']['exception']                   = '鍙戠敓寮傚父';
$_LANG['js_languages']['hide_detail']                   = '闅愯棌缁嗚妭';
$_LANG['js_languages']['suspension_points']                   = '鈥︹€︹€︹€?;
$_LANG['js_languages']['initialize']                   = '鍒濆?鍖?;
$_LANG['js_languages']['wait_please']               = '姝ｅ湪鍗囩骇涓?紝璇风◢鍊欌€︹€︹€︹€?;
$_LANG['js_languages']['has_been_stopped']                    = '鍗囩骇杩涚▼宸蹭腑姝?;
$_LANG['js_languages']['is_last_version']                   = '鎮ㄧ殑ECSHOP宸叉槸鏈€鏂扮増鏈?紝鏃犻渶鍗囩骇銆?;
$_LANG['js_languages']['from']                   = '姝ｅ湪浠?;
$_LANG['js_languages']['to']                   = '鍗囩骇鍒?;
$_LANG['js_languages']['update_files']                   = '鍗囩骇鏂囦欢';
$_LANG['js_languages']['update_structure']                   = '鍗囩骇鏁版嵁缁撴瀯';
$_LANG['js_languages']['update_others']                   = '鍗囩骇鍏跺畠';
$_LANG['js_languages']['success']                   = '瀹屾垚';
$_LANG['js_languages']['fail']                      = '澶辫触';
$_LANG['js_languages']['notice']                      = '鍑洪敊';
$_LANG['js_languages']['dump_database'] = '澶囦唤鏁版嵁';
$_LANG['js_languages']['rollback'] = '鎭㈠?鏁版嵁';
$_LANG['js_languages']['uc_api'] = '璇峰～鍐 UCenter 鐨刄RL';
$_LANG['js_languages']['uc_ip'] = '璇峰～鍐 UCenter 鐨処P';
$_LANG['js_languages']['uc_pwd'] = '璇峰～鍐 UCenter 鍒涘?浜虹殑瀵嗙爜';

/* UCenter 瀹夎?閰嶇疆 */
$_LANG['configure_uc'] = '閰嶇疆UCenter';
$_LANG['check_ucenter'] = '濉?啓瀹屾瘯锛岃繘琛屼笅涓€姝?;
$_LANG['ucapi'] = 'UCenter 鐨 URL锛?;
$_LANG['ucip'] = 'UCenter 鐨 IP锛?;
$_LANG['ucenter'] = '璇峰～鍐 UCenter 鐩稿叧淇℃伅锛?;
$_LANG['ucfounderpw'] = 'UCenter 鍒涘?浜哄瘑鐮侊細';
$_LANG['uc_intro'] = 'UCenter 鏄 Comsenz 鍏?徃浜у搧鐨勬牳蹇冩湇鍔＄▼搴忥紝Discuz! Board 鐨勫畨瑁呭拰杩愯?渚濊禆姝ょ▼搴忋€傚?鏋滄偍宸茬粡瀹夎?浜 UCenter锛岃?濉?啓浠ヤ笅淇℃伅銆傚惁鍒欙紝璇峰埌 <a href="http://www.discuz.com" target="_blank">Comsenz 浜у搧涓?績</a> 涓嬭浇骞朵笖瀹夎?锛岀劧鍚庡啀缁х画銆侟br /><br />';
$_LANG['ucip_intro'] = '杩炴帴鐨勮繃绋嬩腑鍑轰簡鐐归棶棰橈紝璇锋偍濉?啓鏈嶅姟鍣 IP 鍦板潃锛屽?鏋滄偍鐨 UC 涓 ECShop 瑁呭湪鍚屼竴鏈嶅姟鍣ㄤ笂锛屾垜浠?缓璁?偍灏濊瘯濉?啓 127.0.0.1';

$_LANG['users_importto_ucenter'] = '浼氬憳鏁版嵁瀵煎叆鍒 UCenter';
$_LANG['user_startid'] = '浼氬憳 ID 璧峰?鍊硷細';
$_LANG['user_startid_intro'] = '<p>姝よ捣濮嬩細鍛業D涓?s銆傚?鍘 ID 涓 888 鐨勪細鍛樺皢鍙樹负 %s+888 鐨勫€笺€侟/p><br /><p><span style="color:#F00;font-size:1.2em;font-weight:bold;">鎻愰啋锛氬?鍏ヤ細鍛樻暟鎹?墠璇锋殏鍋滃悇涓?簲鐢?濡侱iscuz!, SupeSite绛?</span></p><br />';
$_LANG['maxuid_err'] = '璧峰?浼氬憳 ID 蹇呴』澶т簬绛変簬';
$_LANG['ucenter_import_members'] = '瀵煎叆浼氬憳鏁版嵁鍒癠Center';
$_LANG['ucenter_no_database'] = '<span style="color:#F00;font-size:1.5em;"><b>涓嶈兘杩炴帴鍒癠Center鐨勬暟鎹?簱锛屽崌绾т笉鑳藉畬鎴愶紝璇疯仈绯荤?鐞嗗憳锛?/b></span>';
$_LANG['user_merge_method'] = '浼氬憳鍚堝苟鏂瑰紡锛?;
$_LANG['user_merge_method_1'] = '灏嗕笌UC鐢ㄦ埛鍚嶅拰瀵嗙爜鐩稿悓鐨勭敤鎴峰己鍒朵负鍚屼竴鐢ㄦ埛';
$_LANG['user_merge_method_2'] = '灏嗕笌UC鐢ㄦ埛鍚嶅拰瀵嗙爜鐩稿悓鐨勭敤鎴蜂笉瀵煎叆UC鐢ㄦ埛';
$_LANG['ucenter_not_match'] = '<span style="color:#F00;font-size:1.2em;"><b>UCenter涓嶦CShop瀛楃?缂栫爜涓嶅尮閰嶏紝鍗囩骇涓嶈兘瀹屾垚锛岃?鑱旂郴绠＄悊鍛橈紒</b></span>';

/* 璇?█瀛楃?闆嗛€夋嫨 */
$_LANG['lang_title'] = 'ECShop璇?█缂栫爜';
$_LANG['lang_description'] = '澹版槑';
$_LANG['lang_charset']['zh_cn_gbk'] = '绠€浣撲腑鏂 GBK';
$_LANG['lang_charset']['zh_cn_utf-8'] = '绠€浣撲腑鏂 UTF-8';
$_LANG['lang_charset']['zh_tw_utf-8'] = '绻佷綋涓?枃 UTF-8';
$_LANG['lang_desc']['desc1'] = '璇风‘璁ゆ偍鐨凟CShop绋嬪簭涓庢偍閫夋嫨鐨勮?瑷€缂栫爜涓€鑷达紱';
$_LANG['lang_desc']['desc2'] = '濡傛灉鎮ㄧ殑鏁版嵁搴撲笌ECShop绋嬪簭缂栫爜涓嶄竴鑷达紝鍙?互鍏堣繘琛屾暟鎹?簱缂栫爜杞?崲銆?;
$_LANG['lang_desc']['desc3'] = '<font color="red">濡傛灉鎮ㄦ槸浠嶦CShop v2.6.0鐗堟湰杩涜?鍗囩骇锛屽苟閫夋嫨ECShop鎺ュ彛鏂瑰紡锛岃?鍏堣繘琛屼細鍛樻暟鎹?殑瀵煎叆锛屽惁鍒欏師浼氬憳灏嗘棤娉曠櫥褰曘€侟/font>';

/* 鐢ㄦ埛鎺ュ彛鎻掍欢璇?█椤 */
$_LANG['ui_title'] = '璇烽€夋嫨ECShop浣跨敤鐨勭敤鎴锋帴鍙ｆ彃浠?;
$_LANG['ui_ecshop'] = 'ECShop鏂瑰紡';
$_LANG['ui_ucenter'] = 'UCenter鏂瑰紡';



/* 鍗囩骇鏂囦欢浣跨敤涓?枃鐨勮?瑷€椤 */
$_LANG['update_v250']['zh_cn'] = array('甯愭埛鍐插€?, '甯愭埛鎻愭?', '璐?拱鍟嗗搧', '璁㈠崟閫€娆?, 'init' => '鍒濆?鍖?);
$_LANG['update_v250']['zh_tw'] = array('甯虫埗娌栧€?, '甯虫埗鎻愭?', '璩艰卜鍟嗗搧', '瑷傚柈閫€娆?, 'init' => '鍒濆?鍖?);
$_LANG['update_v250']['en_us'] = array('saving', 'drawing', 'buying', 'refundment',  'init' => 'initialize');
?>
