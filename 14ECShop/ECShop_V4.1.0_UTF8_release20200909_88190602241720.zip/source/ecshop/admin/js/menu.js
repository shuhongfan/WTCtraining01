function t_eval(self){
   return eval("("+ document.getCookie(self.CookieName) +")");
}