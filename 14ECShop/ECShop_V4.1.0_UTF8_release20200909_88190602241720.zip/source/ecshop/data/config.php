<?php
// database host
$db_host   = "localhost";

// database name
$db_name   = "ecshop";

// database username
$db_user   = "root";

// database password
$db_pass   = "root123";

// table prefix
$prefix    = "ecs_";

$timezone    = "Asia/Shanghai";

$cookie_path    = "/";

$cookie_domain    = "";

$session = "1440";

define('EC_CHARSET','utf-8');

define('ADMIN_PATH','admin');

define('AUTH_KEY', 'this is a key');

define('OLD_AUTH_KEY', '');

define('API_TIME', '');

define('STORE_KEY','350e783837b4c8a65a1b2d1d76069c65');

?>