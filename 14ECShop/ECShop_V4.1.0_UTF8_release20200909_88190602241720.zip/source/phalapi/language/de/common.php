<?php
// 德语 de - de 德标
// 德语 de - at 奥地利
// 德语 de - ch 瑞士
// 德语 de - ru 俄罗斯(欧境)
return array(
	'Hi {name}, welcome to use PhalApi!' => '{name}Hallo, Willkommen PhalApi！',
	'user not exists' => 'Der nutzer gibt es nicht',
);
