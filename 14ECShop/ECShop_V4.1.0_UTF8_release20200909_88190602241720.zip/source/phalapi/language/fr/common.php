<?php
// 法语 fr - fr 法标
// 法语 fr - lu 卢森堡
return array(
	'Hi {name}, welcome to use PhalApi!' => '{name}Bonjour, bienvenue PhalApi！',
	'user not exists' => "L'utilisateur n'existe pas",
);
